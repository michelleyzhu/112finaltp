import math, copy, random, time, string
import cv2 as cv2
import numpy as np
from tkinter import *
from cmu_112_graphics import *
from PIL import Image

#Avoid using loops in Python as much as possible, especially double/triple loops etc. They are inherently slow.
#Vectorize the algorithm/code to the maximum extent possible, because Numpy and OpenCV are optimized for vector operations.
#Exploit the cache coherence.
#Never make copies of an array unless it is necessary. Try to use views instead. Array copying is a costly operation.
def pastelFilter(img):
    img = cartoonify(img)
    hsv = cv2.cvtColor(img,cv2.COLOR_BGR2HSV)
    hsv[:,:,1] = hsv[:,:,1] * 0.5
    hsv = hsv.astype(np.uint8)
    #hsv[:,:,2] = hsv[:,:,2] / ((hsv[:,:,2])/256)**2
    return cv2.cvtColor(hsv,cv2.COLOR_HSV2BGR)

def dotFilter(img):
    pass

def pilToCV(img):
    rgb = img.convert('RGB')
    cvIm = np.array(img)
    bgr = cvIm[:,:,::-1]
    return bgr

def cvToPIL(img):
    img = cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
    img = Image.fromarray(img)
    return img
        
# currently, we take in opencv images
#(x0,y0) is the top left corner of the mask
# in relation to img
# assume mask is 0
def overlayMask(img,mask,x0,y0,scale=1):
    if(x0+mask.shape[1] <= img.shape[1] and y0+mask.shape[0] <= img.shape[0]):
        for row in range(mask.shape[0]):
            for col in range(mask.shape[1]):
                rgbTotal = sum(mask[row][col])
                if(rgbTotal < 255*3-20):
                    img[y0+row][x0+col] = mask[row][col]
    else:
        print(f'failed: {x0+mask.shape[1]}>{img.shape[1]} or {y0+mask.shape[0]} > {img.shape[0]}')
    return img

# loosely based off pseudocode of https://www.pyimagesearch.com/2016/07/25/convolutions-with-opencv-and-python/
# I have avoided the cv2 calls made in this tutorial and adapted it for rgb channels
def convolve(inp,kernel):
    inW,inH = inp.shape[1],inp.shape[0]
    kW,kH = kernel.shape[1],kernel.shape[0]
    output = np.empty(inp.shape,dtype='float32')
    
    padW,padH = kW//2,kH//2
    image = np.ones((inH+2*padH,inW+2*padW,inp.shape[2]),dtype='float32')
    image[padH:inH+padH,padW:inW+padW,:] = inp
    '''
    # top border
    image[:padH,padW:-padW,:] = image[padH,padW:-padW,:]
    image[len(image)-padH,padW:-padW,:] = image[len(image)-padH,padW:-padW,:]
    # side border
    image[padH:-padH,0,:] = image[padH:-padH,padW,:]
    image[padH:-padH,len(image[0])-padW,:] = image[padH:-padH,len(image[0])-padW,:]
    # corners
    image[0,            0,:]                = image[1,              1,:]
    image[0,            len(image[0])-1,:]  = image[1,              len(image[0])-2,:]
    image[len(image)-1, len(image[0])-1,:]  = image[len(image)-2,   len(image[0])-2,:]
    image[len(image)-1, 0,:]                = image[len(image)-2,   1,:]
    '''
    count = 0
    for x in np.arange(0,inW):
        for y in np.arange(0,inH):
            roi = image[y:y+2*padH+1,x:x+2*padW+1,:] # a 3d array
            roi1 = (roi[:,:,0]*kernel).sum()
            roi2 = (roi[:,:,1]*kernel).sum()
            roi3 = (roi[:,:,2]*kernel).sum()
            output[y,x] = np.array([roi1,roi2,roi3]) # 3 elem array?
            count += 1
    
    arrMax = np.amax(output)
    arrMin = np.amin(output)
    factor = (arrMax-arrMin+1)/256
    for x in np.arange(0,inW):
        for y in np.arange(0,inH):
            for rgb in np.arange(0,3):
                output[y,x,rgb] = (output[y,x,rgb]-arrMin)/factor

    output = output.astype("uint8")
    return output

# cartoonify() inspired by the tutorial
# https://www.askaswiss.com/2016/01/how-to-create-cartoon-effect-opencv-python.html
def cartoonify(img):
    imgCartoon = img.copy()
    imgColor = imgCartoon.copy()

    pyrLevels = 3
    biPasses = 7
    for i in range(pyrLevels):
        imgColor = cv2.pyrDown(imgColor)
    for i in range(biPasses):
        imgColor = cv2.bilateralFilter(imgColor,d=9,sigmaColor=9,sigmaSpace=7)
    #imgColor = cv2.bilateralFilter(imgColor,d=13,sigmaColor=15,sigmaSpace=15)
    for i in range(pyrLevels):
        imgColor = cv2.pyrUp(imgColor)
    
    imgEdge = cv2.cvtColor(imgCartoon,cv2.COLOR_BGR2GRAY)
    imgEdge = cv2.medianBlur(imgEdge,7)
    imgEdge = cv2.adaptiveThreshold(imgEdge,255,cv2.ADAPTIVE_THRESH_MEAN_C,cv2.THRESH_BINARY,blockSize=9,C=2.5)
    imgEdge = cv2.erode(imgEdge,(5,5),iterations=3)
    #print(imgEdge.shape,imgColor.shape)
    imgCartoon = cv2.bitwise_and(imgColor,imgColor,mask=imgEdge)
    return imgCartoon


# standard convolution kernels from https://www.pyimagesearch.com/2016/07/25/convolutions-with-opencv-and-python/
def testConvolve(img):
    # construct average blurring kernels used to smooth an image
    smallBlur = np.ones((7, 7), dtype="float") * (1.0 / (7 * 7))
    sharpen = np.array((
        [0, -1, 0],
        [-1, 5, -1],
        [0, -1, 0]), dtype="int")
    laplacian = np.array((
        [0, 1, 0],
        [1, -4, 1],
        [0, 1, 0]), dtype="int")
    # construct the Sobel x-axis kernel
    sobelX = np.array((
        [-1, 0, 1],
        [-2, 0, 2],
        [-1, 0, 1]), dtype="int")
    # construct the Sobel y-axis kernel
    sobelY = np.array((
        [-1, -2, -1],
        [0, 0, 0],
        [1, 2, 1]), dtype="int")
    return convolve(img,sharpen)



#### TESTING PURPOSES#####
def dumb():
    vid = cv2.VideoCapture(0)
    cv2.namedWindow('recording')
    ret, frame = vid.read()
    windowFrac = 1/3
    minW, minH = int(frame.shape[1]*windowFrac), int(frame.shape[0]*windowFrac)
    w, h = frame.shape[1], frame.shape[0]
        
    while True:
        ret, frame = vid.read()
        #img = cart(frame)
        img = testConvolve(frame)
        resized = cv2.resize(img,(minW,minH))
        cv2.imshow("recording",resized)
        
        key = cv2.waitKey(1)
        if(key == ord('q')):
            vid.release()
            cv2.destroyAllWindows()
            return

def justIm():
    im = cv2.imread('surprise.jpg')
    im = cv2.resize(im,(im.shape[1]//3,im.shape[0]//3))
    img = testConvolve(im)
    cv2.imwrite("result.jpg",img)
    print("completed")
